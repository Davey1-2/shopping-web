module.exports=[82433,(a,b,c)=>{}];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app__not-found_page_actions_6bbabf40.js.map