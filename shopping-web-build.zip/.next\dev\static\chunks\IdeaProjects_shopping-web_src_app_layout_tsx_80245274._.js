(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__0eedbfac._.css",
  "static/chunks/IdeaProjects_shopping-web_31a2fbf8._.js"
],
    source: "dynamic"
});
