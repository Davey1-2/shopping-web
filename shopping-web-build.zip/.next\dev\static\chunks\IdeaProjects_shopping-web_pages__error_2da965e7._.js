(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/04792_next_dist_compiled_78886ea3._.js",
  "static/chunks/04792_next_dist_shared_lib_f7d5e5bf._.js",
  "static/chunks/04792_next_dist_client_659cc521._.js",
  "static/chunks/04792_next_dist_fae25465._.js",
  "static/chunks/04792_next_error_3295eec1.js",
  "static/chunks/[next]_entry_page-loader_ts_90c4dcdd._.js",
  "static/chunks/04792_react-dom_b9018cf0._.js",
  "static/chunks/04792_cfba2d20._.js",
  "static/chunks/[root-of-the-server]__73c97550._.js"
],
    source: "entry"
});
