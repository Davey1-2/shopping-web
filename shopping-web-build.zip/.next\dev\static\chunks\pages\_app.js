__turbopack_load_page_chunks__("/_app", [
  "static/chunks/04792_next_dist_compiled_78886ea3._.js",
  "static/chunks/04792_next_dist_shared_lib_84506687._.js",
  "static/chunks/04792_next_dist_client_659cc521._.js",
  "static/chunks/04792_next_dist_9b7fc57c._.js",
  "static/chunks/04792_next_app_f7670a6a.js",
  "static/chunks/[next]_entry_page-loader_ts_c418d890._.js",
  "static/chunks/04792_react-dom_b9018cf0._.js",
  "static/chunks/04792_cfba2d20._.js",
  "static/chunks/[root-of-the-server]__fd85cfa8._.js",
  "static/chunks/IdeaProjects_shopping-web_pages__app_2da965e7._.js",
  "static/chunks/turbopack-IdeaProjects_shopping-web_pages__app_cc36b7b2._.js"
])
