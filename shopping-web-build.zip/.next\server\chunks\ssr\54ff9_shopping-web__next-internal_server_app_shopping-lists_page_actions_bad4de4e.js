module.exports=[65578,(a,b,c)=>{}];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app_shopping-lists_page_actions_bad4de4e.js.map