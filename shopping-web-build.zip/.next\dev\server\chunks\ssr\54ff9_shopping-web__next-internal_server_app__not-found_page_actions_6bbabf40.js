module.exports = [
"[project]/IdeaProjects/shopping-web/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app__not-found_page_actions_6bbabf40.js.map