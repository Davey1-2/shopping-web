globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/04792_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bd5fd24d._.js",
    "static/chunks/04792_next_dist_compiled_react-dom_a98b0768._.js",
    "static/chunks/04792_next_dist_compiled_react-server-dom-turbopack_b6e4f019._.js",
    "static/chunks/04792_next_dist_compiled_next-devtools_index_3538b728.js",
    "static/chunks/04792_next_dist_compiled_b710ba3e._.js",
    "static/chunks/04792_next_dist_client_6a99454d._.js",
    "static/chunks/04792_next_dist_6d6a935b._.js",
    "static/chunks/04792_@swc_helpers_cjs_4690c366._.js",
    "static/chunks/IdeaProjects_shopping-web_a0ff3932._.js",
    "static/chunks/turbopack-IdeaProjects_shopping-web_3ae07578._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];