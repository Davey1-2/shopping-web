(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/IdeaProjects/shopping-web/node_modules/next/app.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/IdeaProjects/shopping-web/node_modules/next/dist/pages/_app.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=04792_next_app_f7670a6a.js.map