module.exports=[73904,(e,o,d)=>{}];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app_favicon_ico_route_actions_db758d26.js.map