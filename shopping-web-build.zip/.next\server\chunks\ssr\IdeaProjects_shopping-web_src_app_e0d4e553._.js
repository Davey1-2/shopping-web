module.exports=[46239,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},37690,a=>{"use strict";let b={src:a.i(46239).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=IdeaProjects_shopping-web_src_app_e0d4e553._.js.map