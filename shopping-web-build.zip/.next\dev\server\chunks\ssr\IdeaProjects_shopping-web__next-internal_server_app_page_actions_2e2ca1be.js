module.exports = [
"[project]/IdeaProjects/shopping-web/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=IdeaProjects_shopping-web__next-internal_server_app_page_actions_2e2ca1be.js.map