This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the installation package:

```bash
npm install
```

Then, run the development server:

```bash
npm run dev
```
-----------------------------
You should see your shopping list frontpage.