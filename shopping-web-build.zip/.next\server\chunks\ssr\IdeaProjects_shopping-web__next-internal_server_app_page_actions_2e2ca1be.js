module.exports=[96640,(a,b,c)=>{}];

//# sourceMappingURL=IdeaProjects_shopping-web__next-internal_server_app_page_actions_2e2ca1be.js.map