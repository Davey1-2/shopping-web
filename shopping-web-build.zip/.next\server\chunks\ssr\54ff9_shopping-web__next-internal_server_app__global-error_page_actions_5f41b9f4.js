module.exports=[88749,(a,b,c)=>{}];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app__global-error_page_actions_5f41b9f4.js.map