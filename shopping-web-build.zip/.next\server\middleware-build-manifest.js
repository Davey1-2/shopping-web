globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a13e5b67f2b05c65.js",
    "static/chunks/23cf542afa073b7c.js",
    "static/chunks/ee63f057d9205300.js",
    "static/chunks/04f8286103c88282.js",
    "static/chunks/7547c92d836c25fb.js",
    "static/chunks/turbopack-7189fe0efca82782.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];