module.exports = [
"[project]/IdeaProjects/shopping-web/.next-internal/server/app/shopping-lists/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app_shopping-lists_page_actions_bad4de4e.js.map