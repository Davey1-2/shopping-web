(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bd5fd24d._.js",
  "static/chunks/04792_next_dist_compiled_react-dom_a98b0768._.js",
  "static/chunks/04792_next_dist_compiled_react-server-dom-turbopack_b6e4f019._.js",
  "static/chunks/04792_next_dist_compiled_next-devtools_index_3538b728.js",
  "static/chunks/04792_next_dist_compiled_b710ba3e._.js",
  "static/chunks/04792_next_dist_client_6a99454d._.js",
  "static/chunks/04792_next_dist_6d6a935b._.js",
  "static/chunks/04792_@swc_helpers_cjs_4690c366._.js"
],
    source: "entry"
});
