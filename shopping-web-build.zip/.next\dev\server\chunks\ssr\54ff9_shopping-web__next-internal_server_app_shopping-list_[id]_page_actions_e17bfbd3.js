module.exports = [
"[project]/IdeaProjects/shopping-web/.next-internal/server/app/shopping-list/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app_shopping-list_%5Bid%5D_page_actions_e17bfbd3.js.map