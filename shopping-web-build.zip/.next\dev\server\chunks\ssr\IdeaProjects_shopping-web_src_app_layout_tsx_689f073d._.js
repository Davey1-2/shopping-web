module.exports = [
"[project]/IdeaProjects/shopping-web/src/app/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=IdeaProjects_shopping-web_src_app_layout_tsx_689f073d._.js.map