var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__3f7b0ee7._.js")
R.c("server/chunks/54ff9_shopping-web__next-internal_server_app_favicon_ico_route_actions_db758d26.js")
R.m(85749)
module.exports=R.m(85749).exports
