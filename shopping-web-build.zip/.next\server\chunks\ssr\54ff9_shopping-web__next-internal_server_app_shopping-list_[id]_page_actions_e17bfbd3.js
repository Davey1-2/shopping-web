module.exports=[76537,(a,b,c)=>{}];

//# sourceMappingURL=54ff9_shopping-web__next-internal_server_app_shopping-list_%5Bid%5D_page_actions_e17bfbd3.js.map