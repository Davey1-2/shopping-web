(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/04792_next_dist_compiled_78886ea3._.js",
  "static/chunks/04792_next_dist_shared_lib_84506687._.js",
  "static/chunks/04792_next_dist_client_659cc521._.js",
  "static/chunks/04792_next_dist_9b7fc57c._.js",
  "static/chunks/04792_next_app_f7670a6a.js",
  "static/chunks/[next]_entry_page-loader_ts_c418d890._.js",
  "static/chunks/04792_react-dom_b9018cf0._.js",
  "static/chunks/04792_cfba2d20._.js",
  "static/chunks/[root-of-the-server]__fd85cfa8._.js"
],
    source: "entry"
});
