module.exports = [
  "[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)",
  (__turbopack_context__, module, exports) => {
    const mod = __turbopack_context__.x(
      "next/dist/compiled/next-server/app-page-turbo.runtime.dev.js",
      () =>
        require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js")
    );

    module.exports = mod;
  },
  "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx [app-ssr] (ecmascript)",
  (__turbopack_context__) => {
    "use strict";

    __turbopack_context__.s(["default", () => Navbar]);
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)"
      );
    ("use client");
    function Navbar() {
      return /*#__PURE__*/ (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "jsxDEV"
      ])(
        "nav",
        {
          className: "bg-blue-600 text-white shadow-lg",
          children: /*#__PURE__*/ (0,
          __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
            "jsxDEV"
          ])(
            "div",
            {
              className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
              children: /*#__PURE__*/ (0,
              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                "jsxDEV"
              ])(
                "div",
                {
                  className: "flex justify-between items-center h-16",
                  children: [
                    /*#__PURE__*/ (0,
                    __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                      "jsxDEV"
                    ])(
                      "div",
                      {
                        className: "flex items-center",
                        children: /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "h1",
                          {
                            className: "text-xl font-bold",
                            children: "Shopping Lists",
                          },
                          void 0,
                          false,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
                            lineNumber: 9,
                            columnNumber: 13,
                          },
                          this
                        ),
                      },
                      void 0,
                      false,
                      {
                        fileName:
                          "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
                        lineNumber: 8,
                        columnNumber: 11,
                      },
                      this
                    ),
                    /*#__PURE__*/ (0,
                    __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                      "jsxDEV"
                    ])(
                      "div",
                      {
                        className: "flex items-center space-x-4",
                        children: /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "span",
                          {
                            className: "text-blue-100",
                            children: "Manage your shopping lists",
                          },
                          void 0,
                          false,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
                            lineNumber: 12,
                            columnNumber: 13,
                          },
                          this
                        ),
                      },
                      void 0,
                      false,
                      {
                        fileName:
                          "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
                        lineNumber: 11,
                        columnNumber: 11,
                      },
                      this
                    ),
                  ],
                },
                void 0,
                true,
                {
                  fileName:
                    "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
                  lineNumber: 7,
                  columnNumber: 9,
                },
                this
              ),
            },
            void 0,
            false,
            {
              fileName:
                "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
              lineNumber: 6,
              columnNumber: 7,
            },
            this
          ),
        },
        void 0,
        false,
        {
          fileName:
            "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx",
          lineNumber: 5,
          columnNumber: 5,
        },
        this
      );
    }
  },
  "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx [app-ssr] (ecmascript)",
  (__turbopack_context__) => {
    "use strict";

    __turbopack_context__.s(["default", () => ShoppingListCard]);
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)"
      );
    ("use client");
    function ShoppingListCard({
      shoppingList,
      onEdit,
      onDelete,
      onAddIngredients,
    }) {
      return /*#__PURE__*/ (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "jsxDEV"
      ])(
        "div",
        {
          className:
            "bg-white rounded-lg shadow-md p-6 border border-gray-200 hover:shadow-lg transition-shadow",
          children: [
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              "div",
              {
                className: "flex justify-between items-start mb-4",
                children: [
                  /*#__PURE__*/ (0,
                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                    "jsxDEV"
                  ])(
                    "h3",
                    {
                      className: "text-xl font-semibold text-gray-800",
                      children: shoppingList.name,
                    },
                    void 0,
                    false,
                    {
                      fileName:
                        "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                      lineNumber: 21,
                      columnNumber: 9,
                    },
                    this
                  ),
                  /*#__PURE__*/ (0,
                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                    "jsxDEV"
                  ])(
                    "div",
                    {
                      className: "flex gap-2",
                      children: [
                        /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "button",
                          {
                            onClick: () => onEdit(shoppingList),
                            className:
                              "text-blue-600 hover:text-blue-800 font-medium text-sm",
                            children: "Edit",
                          },
                          void 0,
                          false,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                            lineNumber: 25,
                            columnNumber: 11,
                          },
                          this
                        ),
                        /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "button",
                          {
                            onClick: () => onDelete(shoppingList.id),
                            className:
                              "text-red-600 hover:text-red-800 font-medium text-sm",
                            children: "Delete",
                          },
                          void 0,
                          false,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                            lineNumber: 31,
                            columnNumber: 11,
                          },
                          this
                        ),
                      ],
                    },
                    void 0,
                    true,
                    {
                      fileName:
                        "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                      lineNumber: 24,
                      columnNumber: 9,
                    },
                    this
                  ),
                ],
              },
              void 0,
              true,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                lineNumber: 20,
                columnNumber: 7,
              },
              this
            ),
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              "div",
              {
                className: "mb-4",
                children: [
                  /*#__PURE__*/ (0,
                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                    "jsxDEV"
                  ])(
                    "p",
                    {
                      className: "text-sm text-gray-600 mb-2",
                      children: [
                        "Ingredients (",
                        shoppingList.ingredients.length,
                        "):",
                      ],
                    },
                    void 0,
                    true,
                    {
                      fileName:
                        "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                      lineNumber: 41,
                      columnNumber: 9,
                    },
                    this
                  ),
                  shoppingList.ingredients.length === 0
                    ? /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "p",
                        {
                          className: "text-gray-500 italic",
                          children: "No ingredients added yet",
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                          lineNumber: 45,
                          columnNumber: 11,
                        },
                        this
                      )
                    : /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "ul",
                        {
                          className: "space-y-1 max-h-32 overflow-y-auto",
                          children: shoppingList.ingredients.map(
                            (ingredient, index) =>
                              /*#__PURE__*/ (0,
                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                "jsxDEV"
                              ])(
                                "li",
                                {
                                  className:
                                    "text-gray-700 bg-gray-50 px-2 py-1 rounded text-sm",
                                  children: ["• ", ingredient],
                                },
                                index,
                                true,
                                {
                                  fileName:
                                    "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                                  lineNumber: 49,
                                  columnNumber: 15,
                                },
                                this
                              )
                          ),
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                          lineNumber: 47,
                          columnNumber: 11,
                        },
                        this
                      ),
                ],
              },
              void 0,
              true,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                lineNumber: 40,
                columnNumber: 7,
              },
              this
            ),
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              "div",
              {
                className: "flex gap-2",
                children: /*#__PURE__*/ (0,
                __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                  "jsxDEV"
                ])(
                  "button",
                  {
                    onClick: () => onAddIngredients(shoppingList),
                    className:
                      "flex-1 bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition-colors text-sm font-medium",
                    children:
                      shoppingList.ingredients.length === 0
                        ? "Add Ingredients"
                        : "Manage Ingredients",
                  },
                  void 0,
                  false,
                  {
                    fileName:
                      "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                    lineNumber: 61,
                    columnNumber: 9,
                  },
                  this
                ),
              },
              void 0,
              false,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                lineNumber: 60,
                columnNumber: 7,
              },
              this
            ),
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              "div",
              {
                className: "mt-3 text-xs text-gray-500",
                children: [
                  "Created: ",
                  shoppingList.createdAt.toLocaleDateString(),
                ],
              },
              void 0,
              true,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
                lineNumber: 71,
                columnNumber: 7,
              },
              this
            ),
          ],
        },
        void 0,
        true,
        {
          fileName:
            "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx",
          lineNumber: 19,
          columnNumber: 5,
        },
        this
      );
    }
  },
  "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx [app-ssr] (ecmascript)",
  (__turbopack_context__) => {
    "use strict";

    __turbopack_context__.s(["default", () => Modal]);
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)"
      );
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)"
      );
    ("use client");
    function Modal({
      isOpen,
      onClose,
      onSave,
      title,
      initialIngredients = [],
      initialName = "",
      mode,
    }) {
      const [ingredients, setIngredients] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])(initialIngredients);
      const [currentIngredient, setCurrentIngredient] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])("");
      const [listName, setListName] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])(initialName);
      (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useEffect"
      ])(() => {
        setIngredients(initialIngredients);
        setListName(initialName);
      }, [initialIngredients, initialName, isOpen]);
      const addIngredient = () => {
        if (
          currentIngredient.trim() &&
          !ingredients.includes(currentIngredient.trim())
        ) {
          setIngredients([...ingredients, currentIngredient.trim()]);
          setCurrentIngredient("");
        }
      };
      const removeIngredient = (index) => {
        setIngredients(ingredients.filter((_, i) => i !== index));
      };
      const handleSave = () => {
        if (mode === "edit" && !listName.trim()) {
          return; // Don't save if name is empty in edit mode
        }
        onSave(ingredients, listName);
        onClose();
        setIngredients([]);
        setCurrentIngredient("");
        setListName("");
      };
      const handleClose = () => {
        onClose();
        setIngredients(initialIngredients);
        setCurrentIngredient("");
        setListName(initialName);
      };
      if (!isOpen) return null;
      return /*#__PURE__*/ (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "jsxDEV"
      ])(
        "div",
        {
          className:
            "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",
          children: /*#__PURE__*/ (0,
          __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
            "jsxDEV"
          ])(
            "div",
            {
              className: "bg-white rounded-lg p-6 w-full max-w-md mx-4",
              children: [
                /*#__PURE__*/ (0,
                __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                  "jsxDEV"
                ])(
                  "div",
                  {
                    className: "flex justify-between items-center mb-4",
                    children: [
                      /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "h2",
                        {
                          className: "text-xl font-bold text-gray-800",
                          children: title,
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                          lineNumber: 62,
                          columnNumber: 11,
                        },
                        this
                      ),
                      /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "button",
                        {
                          onClick: handleClose,
                          className:
                            "text-gray-500 hover:text-gray-700 text-2xl",
                          children: "×",
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                          lineNumber: 63,
                          columnNumber: 11,
                        },
                        this
                      ),
                    ],
                  },
                  void 0,
                  true,
                  {
                    fileName:
                      "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                    lineNumber: 61,
                    columnNumber: 9,
                  },
                  this
                ),
                /*#__PURE__*/ (0,
                __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                  "jsxDEV"
                ])(
                  "div",
                  {
                    className: "mb-4",
                    children: [
                      mode === "edit" &&
                        /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "div",
                          {
                            className: "mb-4",
                            children: [
                              /*#__PURE__*/ (0,
                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                "jsxDEV"
                              ])(
                                "label",
                                {
                                  className:
                                    "block text-sm font-medium text-gray-700 mb-2",
                                  children: "Shopping List Name",
                                },
                                void 0,
                                false,
                                {
                                  fileName:
                                    "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                  lineNumber: 74,
                                  columnNumber: 15,
                                },
                                this
                              ),
                              /*#__PURE__*/ (0,
                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                "jsxDEV"
                              ])(
                                "input",
                                {
                                  type: "text",
                                  value: listName,
                                  onChange: (e) => setListName(e.target.value),
                                  placeholder: "Enter list name...",
                                  className:
                                    "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                                },
                                void 0,
                                false,
                                {
                                  fileName:
                                    "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                  lineNumber: 77,
                                  columnNumber: 15,
                                },
                                this
                              ),
                            ],
                          },
                          void 0,
                          true,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                            lineNumber: 73,
                            columnNumber: 13,
                          },
                          this
                        ),
                      /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "div",
                        {
                          className: "flex gap-2 mb-3",
                          children: [
                            /*#__PURE__*/ (0,
                            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                              "jsxDEV"
                            ])(
                              "input",
                              {
                                type: "text",
                                value: currentIngredient,
                                onChange: (e) =>
                                  setCurrentIngredient(e.target.value),
                                onKeyPress: (e) =>
                                  e.key === "Enter" && addIngredient(),
                                placeholder: "Enter ingredient...",
                                className:
                                  "flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                              },
                              void 0,
                              false,
                              {
                                fileName:
                                  "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                lineNumber: 88,
                                columnNumber: 13,
                              },
                              this
                            ),
                            /*#__PURE__*/ (0,
                            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                              "jsxDEV"
                            ])(
                              "button",
                              {
                                onClick: addIngredient,
                                className:
                                  "px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors",
                                children: "Add",
                              },
                              void 0,
                              false,
                              {
                                fileName:
                                  "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                lineNumber: 96,
                                columnNumber: 13,
                              },
                              this
                            ),
                          ],
                        },
                        void 0,
                        true,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                          lineNumber: 87,
                          columnNumber: 11,
                        },
                        this
                      ),
                      /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "div",
                        {
                          className: "max-h-48 overflow-y-auto",
                          children:
                            ingredients.length === 0
                              ? /*#__PURE__*/ (0,
                                __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                  "jsxDEV"
                                ])(
                                  "p",
                                  {
                                    className: "text-gray-500 text-center py-4",
                                    children: "No ingredients added yet",
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName:
                                      "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                    lineNumber: 106,
                                    columnNumber: 15,
                                  },
                                  this
                                )
                              : /*#__PURE__*/ (0,
                                __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                  "jsxDEV"
                                ])(
                                  "ul",
                                  {
                                    className: "space-y-2",
                                    children: ingredients.map(
                                      (ingredient, index) =>
                                        /*#__PURE__*/ (0,
                                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                          "jsxDEV"
                                        ])(
                                          "li",
                                          {
                                            className:
                                              "flex justify-between items-center bg-gray-50 px-3 py-2 rounded-md",
                                            children: [
                                              /*#__PURE__*/ (0,
                                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                                "jsxDEV"
                                              ])(
                                                "span",
                                                {
                                                  className: "text-gray-800",
                                                  children: ingredient,
                                                },
                                                void 0,
                                                false,
                                                {
                                                  fileName:
                                                    "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                                  lineNumber: 116,
                                                  columnNumber: 21,
                                                },
                                                this
                                              ),
                                              /*#__PURE__*/ (0,
                                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                                "jsxDEV"
                                              ])(
                                                "button",
                                                {
                                                  onClick: () =>
                                                    removeIngredient(index),
                                                  className:
                                                    "text-red-500 hover:text-red-700 font-bold",
                                                  children: "×",
                                                },
                                                void 0,
                                                false,
                                                {
                                                  fileName:
                                                    "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                                  lineNumber: 117,
                                                  columnNumber: 21,
                                                },
                                                this
                                              ),
                                            ],
                                          },
                                          index,
                                          true,
                                          {
                                            fileName:
                                              "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                            lineNumber: 112,
                                            columnNumber: 19,
                                          },
                                          this
                                        )
                                    ),
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName:
                                      "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                                    lineNumber: 110,
                                    columnNumber: 15,
                                  },
                                  this
                                ),
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                          lineNumber: 104,
                          columnNumber: 11,
                        },
                        this
                      ),
                    ],
                  },
                  void 0,
                  true,
                  {
                    fileName:
                      "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                    lineNumber: 71,
                    columnNumber: 9,
                  },
                  this
                ),
                /*#__PURE__*/ (0,
                __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                  "jsxDEV"
                ])(
                  "div",
                  {
                    className: "flex gap-3 justify-end",
                    children: [
                      /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "button",
                        {
                          onClick: handleClose,
                          className:
                            "px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors",
                          children: "Cancel",
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                          lineNumber: 131,
                          columnNumber: 11,
                        },
                        this
                      ),
                      /*#__PURE__*/ (0,
                      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                        "jsxDEV"
                      ])(
                        "button",
                        {
                          onClick: handleSave,
                          className:
                            "px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors",
                          children: "Save",
                        },
                        void 0,
                        false,
                        {
                          fileName:
                            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                          lineNumber: 137,
                          columnNumber: 11,
                        },
                        this
                      ),
                    ],
                  },
                  void 0,
                  true,
                  {
                    fileName:
                      "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
                    lineNumber: 130,
                    columnNumber: 9,
                  },
                  this
                ),
              ],
            },
            void 0,
            true,
            {
              fileName:
                "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
              lineNumber: 60,
              columnNumber: 7,
            },
            this
          ),
        },
        void 0,
        false,
        {
          fileName:
            "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx",
          lineNumber: 59,
          columnNumber: 5,
        },
        this
      );
    }
  },
  "[project]/IdeaProjects/shopping-web/src/app/page.tsx [app-ssr] (ecmascript)",
  (__turbopack_context__) => {
    "use strict";

    __turbopack_context__.s(["default", () => Home]);
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)"
      );
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)"
      );
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$src$2f$components$2f$Navbar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/src/components/Navbar.tsx [app-ssr] (ecmascript)"
      );
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$src$2f$components$2f$ShoppingListCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/src/components/ShoppingListCard.tsx [app-ssr] (ecmascript)"
      );
    var __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$src$2f$components$2f$Modal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ =
      __turbopack_context__.i(
        "[project]/IdeaProjects/shopping-web/src/components/Modal.tsx [app-ssr] (ecmascript)"
      );
    ("use client");
    function Home() {
      const [shoppingLists, setShoppingLists] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])([]);
      const [newListName, setNewListName] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])("");
      const [isModalOpen, setIsModalOpen] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])(false);
      const [editingList, setEditingList] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])(null);
      const [modalTitle, setModalTitle] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])("");
      const [modalMode, setModalMode] = (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "useState"
      ])("ingredients");
      const createShoppingList = () => {
        if (newListName.trim()) {
          const newList = {
            id: Date.now().toString(),
            name: newListName.trim(),
            ingredients: [],
            createdAt: new Date(),
          };
          setShoppingLists([...shoppingLists, newList]);
          setNewListName("");
        }
      };
      const deleteShoppingList = (id) => {
        setShoppingLists(shoppingLists.filter((list) => list.id !== id));
      };
      const openIngredientsModal = (list) => {
        setEditingList(list);
        setModalTitle(`Manage Ingredients - ${list.name}`);
        setModalMode("ingredients");
        setIsModalOpen(true);
      };
      const openEditModal = (list) => {
        setEditingList(list);
        setModalTitle(`Edit Shopping List - ${list.name}`);
        setModalMode("edit");
        setIsModalOpen(true);
      };
      const saveChanges = (ingredients, name) => {
        if (editingList) {
          setShoppingLists(
            shoppingLists.map((list) =>
              list.id === editingList.id
                ? {
                    ...list,
                    ingredients,
                    ...(name && {
                      name: name.trim(),
                    }),
                  }
                : list
            )
          );
        }
        setEditingList(null);
      };
      const closeModal = () => {
        setIsModalOpen(false);
        setEditingList(null);
        setModalTitle("");
      };
      return /*#__PURE__*/ (0,
      __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
        "jsxDEV"
      ])(
        "div",
        {
          className: "min-h-screen bg-gray-50",
          children: [
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$src$2f$components$2f$Navbar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                "default"
              ],
              {},
              void 0,
              false,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                lineNumber: 76,
                columnNumber: 7,
              },
              this
            ),
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              "main",
              {
                className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",
                children: [
                  /*#__PURE__*/ (0,
                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                    "jsxDEV"
                  ])(
                    "div",
                    {
                      className: "bg-white rounded-lg shadow-md p-6 mb-8",
                      children: [
                        /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "h2",
                          {
                            className: "text-2xl font-bold text-gray-800 mb-4",
                            children: "Create New Shopping List",
                          },
                          void 0,
                          false,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                            lineNumber: 81,
                            columnNumber: 11,
                          },
                          this
                        ),
                        /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "div",
                          {
                            className: "flex gap-4",
                            children: [
                              /*#__PURE__*/ (0,
                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                "jsxDEV"
                              ])(
                                "input",
                                {
                                  type: "text",
                                  value: newListName,
                                  onChange: (e) =>
                                    setNewListName(e.target.value),
                                  onKeyPress: (e) =>
                                    e.key === "Enter" && createShoppingList(),
                                  placeholder: "Enter shopping list name...",
                                  className:
                                    "flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                },
                                void 0,
                                false,
                                {
                                  fileName:
                                    "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                  lineNumber: 85,
                                  columnNumber: 13,
                                },
                                this
                              ),
                              /*#__PURE__*/ (0,
                              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                "jsxDEV"
                              ])(
                                "button",
                                {
                                  onClick: createShoppingList,
                                  disabled: !newListName.trim(),
                                  className:
                                    "px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors font-medium",
                                  children: "Create",
                                },
                                void 0,
                                false,
                                {
                                  fileName:
                                    "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                  lineNumber: 93,
                                  columnNumber: 13,
                                },
                                this
                              ),
                            ],
                          },
                          void 0,
                          true,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                            lineNumber: 84,
                            columnNumber: 11,
                          },
                          this
                        ),
                      ],
                    },
                    void 0,
                    true,
                    {
                      fileName:
                        "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                      lineNumber: 80,
                      columnNumber: 9,
                    },
                    this
                  ),
                  /*#__PURE__*/ (0,
                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                    "jsxDEV"
                  ])(
                    "div",
                    {
                      className: "mb-6",
                      children: [
                        /*#__PURE__*/ (0,
                        __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                          "jsxDEV"
                        ])(
                          "h2",
                          {
                            className: "text-2xl font-bold text-gray-800 mb-4",
                            children: [
                              "Your Shopping Lists (",
                              shoppingLists.length,
                              ")",
                            ],
                          },
                          void 0,
                          true,
                          {
                            fileName:
                              "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                            lineNumber: 105,
                            columnNumber: 11,
                          },
                          this
                        ),
                        shoppingLists.length === 0
                          ? /*#__PURE__*/ (0,
                            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                              "jsxDEV"
                            ])(
                              "div",
                              {
                                className: "text-center py-12",
                                children: [
                                  /*#__PURE__*/ (0,
                                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                    "jsxDEV"
                                  ])(
                                    "div",
                                    {
                                      className: "text-gray-400 text-6xl mb-4",
                                      children: "🛒",
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName:
                                        "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                      lineNumber: 111,
                                      columnNumber: 15,
                                    },
                                    this
                                  ),
                                  /*#__PURE__*/ (0,
                                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                    "jsxDEV"
                                  ])(
                                    "h3",
                                    {
                                      className:
                                        "text-xl font-medium text-gray-600 mb-2",
                                      children: "No shopping lists yet",
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName:
                                        "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                      lineNumber: 112,
                                      columnNumber: 15,
                                    },
                                    this
                                  ),
                                  /*#__PURE__*/ (0,
                                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                    "jsxDEV"
                                  ])(
                                    "p",
                                    {
                                      className: "text-gray-500",
                                      children:
                                        "Create your first shopping list to get started!",
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName:
                                        "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                      lineNumber: 115,
                                      columnNumber: 15,
                                    },
                                    this
                                  ),
                                ],
                              },
                              void 0,
                              true,
                              {
                                fileName:
                                  "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                lineNumber: 110,
                                columnNumber: 13,
                              },
                              this
                            )
                          : /*#__PURE__*/ (0,
                            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                              "jsxDEV"
                            ])(
                              "div",
                              {
                                className:
                                  "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
                                children: shoppingLists.map((list) =>
                                  /*#__PURE__*/ (0,
                                  __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                    "jsxDEV"
                                  ])(
                                    __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$src$2f$components$2f$ShoppingListCard$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                                      "default"
                                    ],
                                    {
                                      shoppingList: list,
                                      onEdit: openEditModal,
                                      onDelete: deleteShoppingList,
                                      onAddIngredients: openIngredientsModal,
                                    },
                                    list.id,
                                    false,
                                    {
                                      fileName:
                                        "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                      lineNumber: 122,
                                      columnNumber: 17,
                                    },
                                    this
                                  )
                                ),
                              },
                              void 0,
                              false,
                              {
                                fileName:
                                  "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                                lineNumber: 120,
                                columnNumber: 13,
                              },
                              this
                            ),
                      ],
                    },
                    void 0,
                    true,
                    {
                      fileName:
                        "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                      lineNumber: 104,
                      columnNumber: 9,
                    },
                    this
                  ),
                ],
              },
              void 0,
              true,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                lineNumber: 78,
                columnNumber: 7,
              },
              this
            ),
            /*#__PURE__*/ (0,
            __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
              "jsxDEV"
            ])(
              __TURBOPACK__imported__module__$5b$project$5d2f$IdeaProjects$2f$shopping$2d$web$2f$src$2f$components$2f$Modal$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__[
                "default"
              ],
              {
                isOpen: isModalOpen,
                onClose: closeModal,
                onSave: saveChanges,
                title: modalTitle,
                initialIngredients: editingList?.ingredients || [],
                initialName: editingList?.name || "",
                mode: modalMode,
              },
              void 0,
              false,
              {
                fileName:
                  "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
                lineNumber: 136,
                columnNumber: 7,
              },
              this
            ),
          ],
        },
        void 0,
        true,
        {
          fileName: "[project]/IdeaProjects/shopping-web/src/app/page.tsx",
          lineNumber: 75,
          columnNumber: 5,
        },
        this
      );
    }
  },
  "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)",
  (__turbopack_context__, module, exports) => {
    "use strict";

    if (("TURBOPACK compile-time falsy", 0));
    else {
      //TURBOPACK unreachable
      if (("TURBOPACK compile-time falsy", 0));
      else {
        //TURBOPACK unreachable
        if (("TURBOPACK compile-time truthy", 1)) {
          if (("TURBOPACK compile-time truthy", 1)) {
            module.exports = __turbopack_context__.r(
              "[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)"
            );
          } //TURBOPACK unreachable
          else;
        } //TURBOPACK unreachable
        else;
      }
    } //# sourceMappingURL=module.compiled.js.map
  },
  "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)",
  (__turbopack_context__, module, exports) => {
    "use strict";

    module.exports = __turbopack_context__.r(
      "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)"
    ).vendored["react-ssr"].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
  },
  "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)",
  (__turbopack_context__, module, exports) => {
    "use strict";

    module.exports = __turbopack_context__.r(
      "[project]/IdeaProjects/shopping-web/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)"
    ).vendored["react-ssr"].React; //# sourceMappingURL=react.js.map
  },
];

//# sourceMappingURL=%5Broot-of-the-server%5D__a8e9431f._.js.map
